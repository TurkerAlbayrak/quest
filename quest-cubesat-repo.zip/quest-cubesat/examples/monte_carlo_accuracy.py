"""
monte_carlo_accuracy.py
========================
Sweeps sensor noise level and plots the resulting QUEST attitude error,
comparing against the number of reference vectors used (2 vs 4 vs 8).
Produces `monte_carlo_accuracy.png` in the same directory.

Usage:
    python examples/monte_carlo_accuracy.py
"""

import sys
import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
from quest import quest, quat_to_dcm  # noqa: E402


def quat_angle_error_deg(q1, q2):
    dot = np.clip(abs(np.dot(q1, q2)), -1.0, 1.0)
    return np.degrees(2 * np.arccos(dot))


def run_sweep(n_vectors, noise_levels_deg, n_trials=300, seed=0):
    rng = np.random.default_rng(seed)
    theta = np.radians(37.0)
    true_q = np.array([0, 0, np.sin(theta / 2), np.cos(theta / 2)])
    A_true = quat_to_dcm(true_q)

    base_ref = rng.normal(size=(n_vectors, 3))
    base_ref /= np.linalg.norm(base_ref, axis=1, keepdims=True)
    base_body_clean = (A_true @ base_ref.T).T

    mean_errors = []
    std_errors = []
    for noise_deg in noise_levels_deg:
        trial_errors = []
        for _ in range(n_trials):
            noise = rng.normal(scale=np.radians(noise_deg), size=base_body_clean.shape)
            b_noisy = base_body_clean + noise
            b_noisy /= np.linalg.norm(b_noisy, axis=1, keepdims=True)
            result = quest(b_noisy, base_ref)
            trial_errors.append(quat_angle_error_deg(result.quaternion, true_q))
        mean_errors.append(np.mean(trial_errors))
        std_errors.append(np.std(trial_errors))
    return np.array(mean_errors), np.array(std_errors)


def main():
    noise_levels_deg = np.array([0.1, 0.25, 0.5, 1.0, 2.0, 3.0, 5.0])
    vector_counts = [2, 4, 8]

    fig, ax = plt.subplots(figsize=(7.5, 5))
    colors = ["#1f77b4", "#ff7f0e", "#2ca02c"]

    for n_vec, color in zip(vector_counts, colors):
        mean_err, std_err = run_sweep(n_vec, noise_levels_deg, n_trials=300, seed=n_vec)
        ax.plot(noise_levels_deg, mean_err, "-o", color=color,
                label=f"n = {n_vec} vectors")
        ax.fill_between(noise_levels_deg, mean_err - std_err, mean_err + std_err,
                         color=color, alpha=0.15)

    ax.set_xlabel("Per-axis sensor noise (deg, 1-sigma)")
    ax.set_ylabel("QUEST attitude error (deg)")
    ax.set_title("QUEST accuracy vs. sensor noise and number of vector observations")
    ax.legend()
    ax.grid(alpha=0.3)

    out_path = os.path.join(os.path.dirname(__file__), "monte_carlo_accuracy.png")
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    print(f"Saved plot to {out_path}")


if __name__ == "__main__":
    main()
