"""
sun_magnetometer_example.py
============================
Realistic-ish CubeSat scenario: estimating attitude from a coarse sun
sensor and a 3-axis magnetometer, the two most common sensors on a
1U/3U CubeSat ADCS.

This mirrors the numeric example discussed in docs/quest_algorithm.pdf
(Section 7 -- Sayısal Örnek).
"""

import sys
import os
import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
from quest import quest, quat_to_dcm  # noqa: E402


def main():
    rng = np.random.default_rng(0)

    # --- Ground truth attitude: 30 deg about Z, unknown to the estimator ---
    true_theta = np.radians(30.0)
    true_q = np.array([0.0, 0.0, np.sin(true_theta / 2), np.cos(true_theta / 2)])
    A_true = quat_to_dcm(true_q)

    # --- Reference vectors in the inertial frame (from ephemeris / IGRF) ---
    sun_inertial = np.array([1.0, 0.0, 0.0])
    mag_inertial = np.array([0.0, 0.0, 1.0])  # simplified for the example

    # --- Simulated sensor measurements in the body frame (with noise) ---
    sun_sensor_noise_deg = 0.5     # coarse sun sensors: ~0.5-2 deg typical
    magnetometer_noise_deg = 1.0   # magnetometers: ~1-3 deg typical (biases too)

    sun_body_clean = A_true @ sun_inertial
    mag_body_clean = A_true @ mag_inertial

    sun_body = sun_body_clean + rng.normal(scale=np.radians(sun_sensor_noise_deg), size=3)
    mag_body = mag_body_clean + rng.normal(scale=np.radians(magnetometer_noise_deg), size=3)
    sun_body /= np.linalg.norm(sun_body)
    mag_body /= np.linalg.norm(mag_body)

    # --- Weights: inverse-variance-like, sun sensor trusted more here ---
    w_sun = 1.0 / sun_sensor_noise_deg**2
    w_mag = 1.0 / magnetometer_noise_deg**2
    weights = np.array([w_sun, w_mag])
    weights /= weights.sum()

    body_vectors = np.vstack([sun_body, mag_body])
    ref_vectors = np.vstack([sun_inertial, mag_inertial])

    result = quest(body_vectors, ref_vectors, weights)

    # --- Report ---
    dot = np.clip(abs(np.dot(result.quaternion, true_q)), -1.0, 1.0)
    angle_err_deg = np.degrees(2 * np.arccos(dot))

    print("=" * 60)
    print(" QUEST -- Sun sensor + magnetometer attitude estimate")
    print("=" * 60)
    print(f"True quaternion       : {np.round(true_q, 5)}")
    print(f"Estimated quaternion  : {np.round(result.quaternion, 5)}")
    print(f"Angular error         : {angle_err_deg:.4f} deg")
    print(f"lambda_max            : {result.lambda_max:.8f}")
    print(f"Wahba loss J_min      : {result.loss:.3e}")
    print(f"Newton-Raphson iters  : {result.n_iterations}")
    print()
    print("Weights used           :", np.round(weights, 4),
          "(sun sensor, magnetometer)")


if __name__ == "__main__":
    main()
