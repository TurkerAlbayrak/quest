"""
triad_vs_quest.py
===================
Compares the simple TRIAD algorithm (2-vector, non-optimal, no weighting)
against QUEST (n-vector, weighted, least-squares optimal) under identical
noisy measurement conditions. Demonstrates why QUEST is generally
preferred whenever more than two independent measurements are available.
"""

import sys
import os
import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
from quest import quest, quat_to_dcm  # noqa: E402


def triad(b1, b2, r1, r2):
    """Classic TRIAD algorithm: returns the 3x3 DCM from two vector pairs.

    Only uses the two given vectors; does not support weighting or more
    than two observations. b1/r1 is treated as the more trusted pair.
    """
    b1 = b1 / np.linalg.norm(b1)
    b2 = b2 / np.linalg.norm(b2)
    r1 = r1 / np.linalg.norm(r1)
    r2 = r2 / np.linalg.norm(r2)

    t1_b = b1
    t2_b = np.cross(b1, b2) / np.linalg.norm(np.cross(b1, b2))
    t3_b = np.cross(t1_b, t2_b)

    t1_r = r1
    t2_r = np.cross(r1, r2) / np.linalg.norm(np.cross(r1, r2))
    t3_r = np.cross(t1_r, t2_r)

    M_b = np.column_stack([t1_b, t2_b, t3_b])
    M_r = np.column_stack([t1_r, t2_r, t3_r])
    return M_b @ M_r.T


def dcm_angle_error_deg(A_est, A_true):
    R_err = A_est @ A_true.T
    cos_angle = np.clip((np.trace(R_err) - 1) / 2, -1.0, 1.0)
    return np.degrees(np.arccos(cos_angle))


def main():
    rng = np.random.default_rng(3)
    theta = np.radians(48.0)
    true_q = np.array([0.1, 0.2, np.sin(theta / 2), np.cos(theta / 2)])
    true_q /= np.linalg.norm(true_q)
    A_true = quat_to_dcm(true_q)

    # 4 reference vectors: sun, mag, and 2 star-tracker-like references
    r = np.array([
        [1.0, 0.0, 0.0],
        [0.0, 0.0, 1.0],
        [0.0, 1.0, 0.0],
        [0.577, 0.577, 0.577],
    ])
    b_clean = (A_true @ r.T).T

    noise_deg = np.array([0.3, 1.5, 0.8, 0.4])  # sun sensor most accurate here
    n_trials = 500
    triad_errors, quest_errors = [], []

    for _ in range(n_trials):
        b_noisy = b_clean + rng.normal(
            scale=np.radians(noise_deg)[:, None], size=b_clean.shape
        )
        b_noisy /= np.linalg.norm(b_noisy, axis=1, keepdims=True)

        # TRIAD only ever sees 2 vectors -- use the 2 most accurate ones.
        A_triad = triad(b_noisy[0], b_noisy[3], r[0], r[3])
        triad_errors.append(dcm_angle_error_deg(A_triad, A_true))

        # QUEST uses all 4, weighted by inverse noise variance.
        weights = 1.0 / noise_deg**2
        result = quest(b_noisy, r, weights)
        A_quest = quat_to_dcm(result.quaternion)
        quest_errors.append(dcm_angle_error_deg(A_quest, A_true))

    print("=" * 55)
    print(f" TRIAD  (2 vectors) : mean = {np.mean(triad_errors):.3f} deg, "
          f"std = {np.std(triad_errors):.3f} deg")
    print(f" QUEST  (4 vectors) : mean = {np.mean(quest_errors):.3f} deg, "
          f"std = {np.std(quest_errors):.3f} deg")
    print("=" * 55)
    improvement = (np.mean(triad_errors) - np.mean(quest_errors)) / np.mean(triad_errors) * 100
    print(f"QUEST reduces mean attitude error by {improvement:.1f}% "
          f"by fusing all available measurements.")


if __name__ == "__main__":
    main()
