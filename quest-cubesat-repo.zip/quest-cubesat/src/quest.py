"""
quest.py
========
QUEST (QUaternion ESTimator) attitude determination algorithm.

Reference:
    M. D. Shuster and S. D. Oh, "Three-Axis Attitude Determination from
    Vector Observations," Journal of Guidance and Control, 4(1), 1981.

This is a reference / educational implementation intended for CubeSat
ADCS (Attitude Determination and Control System) ground-testing and
simulation. It favors clarity over raw performance; see
`src/quest_embedded.c` for a fixed-loop, allocation-free C port suitable
for flight software.

Quaternion convention: scalar-last, i.e. q = [qx, qy, qz, qw],
representing the rotation FROM the inertial frame TO the body frame:
    b_i = A(q) @ r_i
"""

from __future__ import annotations

import numpy as np
from dataclasses import dataclass


class QuestError(RuntimeError):
    """Raised when QUEST cannot produce a valid attitude solution."""


@dataclass
class QuestResult:
    """Container for QUEST algorithm output and diagnostics."""

    quaternion: np.ndarray      # [qx, qy, qz, qw], unit norm
    lambda_max: float           # optimal (largest) eigenvalue of K
    loss: float                 # Wahba loss J(A_opt) = sum(a_i) - lambda_max
    n_iterations: int           # Newton-Raphson iterations used
    converged: bool             # whether Newton-Raphson converged


def _skew_sum_z(B: np.ndarray) -> np.ndarray:
    """z vector built from the antisymmetric part of B (Eq. 8 in the PDF)."""
    return np.array([
        B[1, 2] - B[2, 1],
        B[2, 0] - B[0, 2],
        B[0, 1] - B[1, 0],
    ])


def attitude_profile_matrix(
    body_vectors: np.ndarray,
    ref_vectors: np.ndarray,
    weights: np.ndarray,
) -> np.ndarray:
    """
    Build the attitude profile matrix B = sum_i a_i * b_i * r_i^T.

    Parameters
    ----------
    body_vectors : (n, 3) array of unit vectors in the body frame
    ref_vectors  : (n, 3) array of unit vectors in the inertial frame
    weights      : (n,) array of non-negative weights (need not sum to 1)

    Returns
    -------
    (3, 3) attitude profile matrix B
    """
    B = np.zeros((3, 3))
    for a_i, b_i, r_i in zip(weights, body_vectors, ref_vectors):
        B += a_i * np.outer(b_i, r_i)
    return B


def _newton_raphson_lambda_max(
    a: float, b: float, c: float, d: float, sigma: float,
    lambda0: float, tol: float = 1e-12, max_iter: int = 25,
) -> tuple[float, int, bool]:
    """
    Solve f(lambda) = lambda^4 - (a+b) lambda^2 - c*lambda + (a*b + c*sigma - d) = 0
    for the root closest to lambda0 (the sum-of-weights initial guess).
    """
    lam = lambda0
    converged = False
    n_iter = 0
    for n_iter in range(1, max_iter + 1):
        f = lam**4 - (a + b) * lam**2 - c * lam + (a * b + c * sigma - d)
        fp = 4 * lam**3 - 2 * (a + b) * lam - c
        if fp == 0.0:
            raise QuestError("Newton-Raphson derivative vanished (fp == 0).")
        lam_new = lam - f / fp
        if abs(lam_new - lam) < tol:
            lam = lam_new
            converged = True
            break
        lam = lam_new
    return lam, n_iter, converged


def quest(
    body_vectors,
    ref_vectors,
    weights=None,
    tol: float = 1e-12,
    max_iter: int = 25,
) -> QuestResult:
    """
    Compute the optimal attitude quaternion from n >= 2 vector observation
    pairs using the QUEST algorithm.

    Parameters
    ----------
    body_vectors : array-like, shape (n, 3)
        Unit vectors as measured in the spacecraft body frame
        (e.g. sun sensor, magnetometer readings, normalized).
    ref_vectors : array-like, shape (n, 3)
        The same physical vectors expressed in the inertial frame
        (e.g. from a sun ephemeris or IGRF magnetic field model).
    weights : array-like, shape (n,), optional
        Relative confidence weights (inverse of measurement variance is a
        common choice). Defaults to equal weights.
    tol : float
        Newton-Raphson convergence tolerance on lambda_max.
    max_iter : int
        Maximum Newton-Raphson iterations before giving up.

    Returns
    -------
    QuestResult
        quaternion (scalar-last), lambda_max, Wahba loss, and diagnostics.

    Raises
    ------
    QuestError
        If fewer than 2 vector pairs are given, if reference vectors are
        (near-)parallel (rank-deficient B), or if Newton-Raphson fails to
        converge.
    """
    b = np.asarray(body_vectors, dtype=float).reshape(-1, 3)
    r = np.asarray(ref_vectors, dtype=float).reshape(-1, 3)

    if b.shape[0] < 2:
        raise QuestError("QUEST requires at least 2 vector observation pairs.")
    if b.shape != r.shape:
        raise QuestError("body_vectors and ref_vectors must have the same shape.")

    if weights is None:
        w = np.ones(b.shape[0]) / b.shape[0]
    else:
        w = np.asarray(weights, dtype=float)
        if w.shape[0] != b.shape[0]:
            raise QuestError("weights must have the same length as the vector lists.")

    # Normalize inputs defensively (QUEST assumes unit vectors).
    b = b / np.linalg.norm(b, axis=1, keepdims=True)
    r = r / np.linalg.norm(r, axis=1, keepdims=True)

    # --- Reject (near-)degenerate reference geometry -----------------
    if b.shape[0] == 2:
        cos_angle = np.clip(np.dot(r[0], r[1]), -1.0, 1.0)
        if abs(cos_angle) > 0.9998:  # < ~1 degree apart or antiparallel
            raise QuestError(
                "Reference vectors are (nearly) parallel/antiparallel; "
                "attitude is unobservable about the shared axis."
            )

    # --- Step 1-2: profile matrix, sigma, S, z ------------------------
    B = attitude_profile_matrix(b, r, w)
    sigma = np.trace(B)
    S = B + B.T
    z = _skew_sum_z(B)

    # --- Step 3: characteristic-equation coefficients -----------------
    adjS = np.linalg.det(S) * np.linalg.inv(S) if np.linalg.det(S) != 0 else \
        _adjugate_3x3(S)
    kappa = np.trace(adjS)
    a = sigma**2 - kappa
    bcoef = sigma**2 + z @ z
    c = np.linalg.det(S) + z @ S @ z
    d = z @ (S @ S) @ z

    lambda0 = np.sum(w)

    # --- Step 4: Newton-Raphson for lambda_max ------------------------
    lam, n_iter, converged = _newton_raphson_lambda_max(
        a, bcoef, c, d, sigma, lambda0, tol=tol, max_iter=max_iter
    )
    if not converged:
        raise QuestError(
            f"Newton-Raphson did not converge within {max_iter} iterations."
        )

    # --- Step 5: Gibbs vector (Rodrigues parameters) -------------------
    M = (lam + sigma) * np.eye(3) - S
    try:
        p = np.linalg.solve(M, z)
    except np.linalg.LinAlgError as exc:
        raise QuestError(
            "Singular Gibbs-vector system (rotation angle near 180 deg); "
            "use sequential QUEST (see quest_sequential())."
        ) from exc

    # --- Step 6: assemble & normalize quaternion -----------------------
    q_unnorm = np.array([p[0], p[1], p[2], 1.0])
    q = q_unnorm / np.linalg.norm(q_unnorm)

    loss = float(lambda0 - lam)
    return QuestResult(
        quaternion=q, lambda_max=float(lam), loss=loss,
        n_iterations=n_iter, converged=converged,
    )


def _adjugate_3x3(M: np.ndarray) -> np.ndarray:
    """Adjugate (classical adjoint) of a 3x3 matrix, safe for singular M."""
    cof = np.zeros((3, 3))
    for i in range(3):
        for j in range(3):
            minor = np.delete(np.delete(M, i, axis=0), j, axis=1)
            cof[i, j] = ((-1) ** (i + j)) * np.linalg.det(minor)
    return cof.T


def quest_sequential(body_vectors, ref_vectors, weights=None, **kwargs) -> QuestResult:
    """
    Robust wrapper around `quest()` that sidesteps the Gibbs-vector
    singularity near a 180-degree rotation angle.

    Strategy: run QUEST in the original frame and in a frame pre-rotated
    by 90 degrees about the reference triad's dominant axis; keep the
    solution whose scalar quaternion component has the larger magnitude
    (i.e. the one farther from the q4 -> 0 singularity), then rotate the
    result back.
    """
    r = np.asarray(ref_vectors, dtype=float).reshape(-1, 3)

    try:
        result_direct = quest(body_vectors, ref_vectors, weights, **kwargs)
    except QuestError:
        result_direct = None

    # 90-degree rotation about the Z axis of the reference frame.
    Rz90 = np.array([
        [0.0, -1.0, 0.0],
        [1.0, 0.0, 0.0],
        [0.0, 0.0, 1.0],
    ])
    r_rot = r @ Rz90.T
    try:
        result_rot = quest(body_vectors, r_rot, weights, **kwargs)
        # Rotate the resulting quaternion's vector part back by -90 deg
        # about Z (compose with the inverse of the auxiliary rotation).
        q_aux = np.array([0.0, 0.0, np.sin(-np.pi / 4), np.cos(-np.pi / 4)])
        result_rot = QuestResult(
            quaternion=_quat_multiply(result_rot.quaternion, q_aux),
            lambda_max=result_rot.lambda_max,
            loss=result_rot.loss,
            n_iterations=result_rot.n_iterations,
            converged=result_rot.converged,
        )
    except QuestError:
        result_rot = None

    candidates = [x for x in (result_direct, result_rot) if x is not None]
    if not candidates:
        raise QuestError("Both direct and sequential-rotation QUEST solutions failed.")

    return max(candidates, key=lambda res: abs(res.quaternion[3]))


def _quat_multiply(q1: np.ndarray, q2: np.ndarray) -> np.ndarray:
    """Hamilton product of two scalar-last quaternions q1 * q2."""
    x1, y1, z1, w1 = q1
    x2, y2, z2, w2 = q2
    return np.array([
        w1 * x2 + x1 * w2 + y1 * z2 - z1 * y2,
        w1 * y2 - x1 * z2 + y1 * w2 + z1 * x2,
        w1 * z2 + x1 * y2 - y1 * x2 + z1 * w2,
        w1 * w2 - x1 * x2 - y1 * y2 - z1 * z2,
    ])


def quat_to_dcm(q: np.ndarray) -> np.ndarray:
    """Convert a scalar-last unit quaternion to a 3x3 direction cosine matrix."""
    x, y, z, w = q
    return np.array([
        [1 - 2 * (y**2 + z**2),     2 * (x * y + z * w),     2 * (x * z - y * w)],
        [    2 * (x * y - z * w), 1 - 2 * (x**2 + z**2),     2 * (y * z + x * w)],
        [    2 * (x * z + y * w),     2 * (y * z - x * w), 1 - 2 * (x**2 + y**2)],
    ])


if __name__ == "__main__":
    # Minimal smoke test: 30-degree rotation about Z, two reference vectors.
    theta = np.radians(30.0)
    true_q = np.array([0.0, 0.0, np.sin(theta / 2), np.cos(theta / 2)])
    A_true = quat_to_dcm(true_q)

    r_vecs = np.array([[1.0, 0.0, 0.0], [0.0, 0.0, 1.0]])
    b_vecs = (A_true @ r_vecs.T).T

    result = quest(b_vecs, r_vecs, weights=[0.7, 0.3])
    print("Estimated quaternion :", np.round(result.quaternion, 6))
    print("True quaternion      :", np.round(true_q, 6))
    print("lambda_max           :", result.lambda_max)
    print("Wahba loss            :", result.loss)
    print("Newton-Raphson iters  :", result.n_iterations)
