/**
 * quest_embedded.c
 * =================
 * Allocation-free, fixed-iteration QUEST (QUaternion ESTimator) implementation
 * intended for CubeSat flight software running on resource-constrained
 * microcontrollers (e.g. ARM Cortex-M, MSP430).
 *
 * Design goals:
 *   - No dynamic memory allocation (no malloc/free).
 *   - No exceptions; error reporting via return codes (quest_status_t).
 *   - Fixed maximum Newton-Raphson iteration count (bounded worst-case time).
 *   - Works with `float` (32-bit) by default; switch QUEST_REAL to `double`
 *     if your MCU has an FPU with double-precision support and the extra
 *     accuracy is needed.
 *
 * Reference: M. D. Shuster and S. D. Oh, "Three-Axis Attitude Determination
 * from Vector Observations," J. Guidance and Control, 4(1), 1981.
 *
 * Quaternion convention: scalar-last [qx, qy, qz, qw], body <- inertial.
 *
 * Usage example is at the bottom of this file under `#ifdef QUEST_TEST_MAIN`.
 * Build the self-test with:
 *     cc -O2 -DQUEST_TEST_MAIN -lm quest_embedded.c -o quest_test
 */

#include <math.h>
#include <string.h>

/* ------------------------------------------------------------------ */
/* Configuration                                                       */
/* ------------------------------------------------------------------ */

typedef float QUEST_REAL;              /* use `double` for higher precision */

#define QUEST_MAX_VECTORS   8          /* max simultaneous observations     */
#define QUEST_MAX_NR_ITERS  25          /* Newton-Raphson iteration cap      */
/* NOTE: 1e-9 is unreachable in 32-bit float (≈7 decimal digits of
 * precision), so the default tolerance is set for `float`. If you switch
 * QUEST_REAL to `double`, you may tighten this to 1e-12. */
#define QUEST_NR_TOL        ((QUEST_REAL)1e-6)
#define QUEST_PARALLEL_COS_THRESH ((QUEST_REAL)0.9998) /* ~1 deg */

typedef enum {
    QUEST_OK = 0,
    QUEST_ERR_TOO_FEW_VECTORS = -1,
    QUEST_ERR_TOO_MANY_VECTORS = -2,
    QUEST_ERR_PARALLEL_REFERENCE = -3,
    QUEST_ERR_SINGULAR_GIBBS = -4,
    QUEST_ERR_NR_NOT_CONVERGED = -5,
    QUEST_ERR_ZERO_DERIVATIVE = -6,
} quest_status_t;

typedef struct {
    QUEST_REAL x, y, z, w;   /* scalar-last quaternion */
} quest_quat_t;

typedef struct {
    QUEST_REAL v[3];
} quest_vec3_t;

typedef struct {
    quest_quat_t quaternion;
    QUEST_REAL   lambda_max;
    QUEST_REAL   loss;
    int          n_iterations;
} quest_result_t;

/* ------------------------------------------------------------------ */
/* Small linear-algebra helpers (no heap, fixed 3x3 / 3-vector sizes)  */
/* ------------------------------------------------------------------ */

static QUEST_REAL v3_dot(const QUEST_REAL a[3], const QUEST_REAL b[3]) {
    return a[0]*b[0] + a[1]*b[1] + a[2]*b[2];
}

/* Exposed for callers who need to normalize raw sensor readings before
 * passing them to quest_solve() (not used internally, since inputs are
 * assumed pre-normalized). */
void quest_vec3_normalize(QUEST_REAL v[3]) {
    QUEST_REAL n = (QUEST_REAL)sqrt((double)v3_dot(v, v));
    if (n > (QUEST_REAL)1e-15) {
        v[0] /= n; v[1] /= n; v[2] /= n;
    }
}

static void mat3_mulvec(const QUEST_REAL M[3][3], const QUEST_REAL v[3], QUEST_REAL out[3]) {
    for (int i = 0; i < 3; ++i)
        out[i] = M[i][0]*v[0] + M[i][1]*v[1] + M[i][2]*v[2];
}

static QUEST_REAL mat3_det(const QUEST_REAL M[3][3]) {
    return M[0][0]*(M[1][1]*M[2][2] - M[1][2]*M[2][1])
         - M[0][1]*(M[1][0]*M[2][2] - M[1][2]*M[2][0])
         + M[0][2]*(M[1][0]*M[2][1] - M[1][1]*M[2][0]);
}

/* Adjugate (classical adjoint) of a 3x3 matrix -- used for the 'a' coefficient
 * (trace of the adjugate of S) and does not require S to be invertible. */
static void mat3_adjugate(const QUEST_REAL M[3][3], QUEST_REAL adj[3][3]) {
    adj[0][0] =  (M[1][1]*M[2][2] - M[1][2]*M[2][1]);
    adj[0][1] = -(M[0][1]*M[2][2] - M[0][2]*M[2][1]);
    adj[0][2] =  (M[0][1]*M[1][2] - M[0][2]*M[1][1]);
    adj[1][0] = -(M[1][0]*M[2][2] - M[1][2]*M[2][0]);
    adj[1][1] =  (M[0][0]*M[2][2] - M[0][2]*M[2][0]);
    adj[1][2] = -(M[0][0]*M[1][2] - M[0][2]*M[1][0]);
    adj[2][0] =  (M[1][0]*M[2][1] - M[1][1]*M[2][0]);
    adj[2][1] = -(M[0][0]*M[2][1] - M[0][1]*M[2][0]);
    adj[2][2] =  (M[0][0]*M[1][1] - M[0][1]*M[1][0]);
    /* Note: adjugate is the transpose of the cofactor matrix; the
     * expressions above already produce that transpose directly, so we
     * copy without an extra transpose step. */
    QUEST_REAL tmp[3][3];
    memcpy(tmp, adj, sizeof(tmp));
    adj[0][1] = tmp[1][0]; adj[1][0] = tmp[0][1];
    adj[0][2] = tmp[2][0]; adj[2][0] = tmp[0][2];
    adj[1][2] = tmp[2][1]; adj[2][1] = tmp[1][2];
}

/* Solve M x = z for a general (possibly asymmetric) 3x3 system via
 * Cramer's rule. Returns 0 on success, -1 if M is (near-)singular. */
static int mat3_solve(const QUEST_REAL M[3][3], const QUEST_REAL z[3], QUEST_REAL x[3]) {
    QUEST_REAL det = mat3_det(M);
    if (fabs((double)det) < 1e-12) {
        return -1;
    }
    QUEST_REAL Mi[3][3];

    for (int col = 0; col < 3; ++col) {
        memcpy(Mi, M, sizeof(Mi));
        for (int row = 0; row < 3; ++row) Mi[row][col] = z[row];
        x[col] = mat3_det(Mi) / det;
    }
    return 0;
}

/* ------------------------------------------------------------------ */
/* Core QUEST algorithm                                                */
/* ------------------------------------------------------------------ */

/**
 * quest_solve
 * -----------
 * @param body_vecs   array of n unit vectors in the body frame
 * @param ref_vecs    array of n unit vectors in the inertial frame
 * @param weights     array of n non-negative weights (NULL => equal weights)
 * @param n           number of vector pairs (2 <= n <= QUEST_MAX_VECTORS)
 * @param out         result struct (quaternion, lambda_max, loss, iters)
 * @return QUEST_OK on success, or a quest_status_t error code.
 *
 * No heap allocation; all intermediate storage is on the stack / caller-owned.
 */
quest_status_t quest_solve(const quest_vec3_t *body_vecs,
                            const quest_vec3_t *ref_vecs,
                            const QUEST_REAL *weights,
                            int n,
                            quest_result_t *out)
{
    if (n < 2) return QUEST_ERR_TOO_FEW_VECTORS;
    if (n > QUEST_MAX_VECTORS) return QUEST_ERR_TOO_MANY_VECTORS;

    QUEST_REAL w[QUEST_MAX_VECTORS];
    QUEST_REAL lambda0 = 0;
    for (int i = 0; i < n; ++i) {
        w[i] = weights ? weights[i] : (QUEST_REAL)1.0 / (QUEST_REAL)n;
        lambda0 += w[i];
    }

    /* Reject (near-)parallel reference geometry for the 2-vector case. */
    if (n == 2) {
        QUEST_REAL cos_ang = v3_dot(ref_vecs[0].v, ref_vecs[1].v);
        if (cos_ang > QUEST_PARALLEL_COS_THRESH || cos_ang < -QUEST_PARALLEL_COS_THRESH)
            return QUEST_ERR_PARALLEL_REFERENCE;
    }

    /* Step 1: attitude profile matrix B = sum_i w_i b_i r_i^T */
    QUEST_REAL B[3][3] = {{0}};
    for (int i = 0; i < n; ++i) {
        const QUEST_REAL *b = body_vecs[i].v;
        const QUEST_REAL *r = ref_vecs[i].v;
        for (int row = 0; row < 3; ++row)
            for (int col = 0; col < 3; ++col)
                B[row][col] += w[i] * b[row] * r[col];
    }

    /* Step 2: sigma, S, z */
    QUEST_REAL sigma = B[0][0] + B[1][1] + B[2][2];
    QUEST_REAL S[3][3];
    for (int i = 0; i < 3; ++i)
        for (int j = 0; j < 3; ++j)
            S[i][j] = B[i][j] + B[j][i];

    QUEST_REAL z[3] = {
        B[1][2] - B[2][1],
        B[2][0] - B[0][2],
        B[0][1] - B[1][0],
    };

    /* Step 3: characteristic polynomial coefficients a, b, c, d */
    QUEST_REAL adjS[3][3];
    mat3_adjugate(S, adjS);
    QUEST_REAL kappa = adjS[0][0] + adjS[1][1] + adjS[2][2]; /* trace(adj(S)) */

    QUEST_REAL a = sigma * sigma - kappa;
    QUEST_REAL bcoef = sigma * sigma + v3_dot(z, z);

    QUEST_REAL Sz[3];
    mat3_mulvec(S, z, Sz);
    QUEST_REAL c = mat3_det(S) + v3_dot(z, Sz);

    QUEST_REAL SSz[3];
    mat3_mulvec(S, Sz, SSz);
    QUEST_REAL d = v3_dot(z, SSz);

    /* Step 4: Newton-Raphson for lambda_max, seeded at lambda0 */
    QUEST_REAL lam = lambda0;
    int iter;
    int converged = 0;
    for (iter = 1; iter <= QUEST_MAX_NR_ITERS; ++iter) {
        QUEST_REAL lam2 = lam * lam;
        QUEST_REAL f  = lam2 * lam2 - (a + bcoef) * lam2 - c * lam + (a * bcoef + c * sigma - d);
        QUEST_REAL fp = 4 * lam2 * lam - 2 * (a + bcoef) * lam - c;
        if (fabs((double)fp) < 1e-15) {
            return QUEST_ERR_ZERO_DERIVATIVE;
        }
        QUEST_REAL lam_new = lam - f / fp;
        QUEST_REAL delta = (QUEST_REAL)fabs((double)(lam_new - lam));
        lam = lam_new;
        if (delta < QUEST_NR_TOL) { converged = 1; break; }
    }
    if (!converged) return QUEST_ERR_NR_NOT_CONVERGED;

    /* Step 5: Gibbs vector p = [(lambda+sigma) I - S]^-1 z */
    QUEST_REAL M[3][3];
    for (int i = 0; i < 3; ++i)
        for (int j = 0; j < 3; ++j)
            M[i][j] = ((i == j) ? (lam + sigma) : 0) - S[i][j];

    QUEST_REAL p[3];
    if (mat3_solve(M, z, p) != 0) {
        return QUEST_ERR_SINGULAR_GIBBS; /* near 180-degree rotation */
    }

    /* Step 6: assemble & normalize quaternion */
    QUEST_REAL qv[4] = { p[0], p[1], p[2], (QUEST_REAL)1.0 };
    QUEST_REAL norm = (QUEST_REAL)sqrt((double)(qv[0]*qv[0] + qv[1]*qv[1] + qv[2]*qv[2] + qv[3]*qv[3]));

    out->quaternion.x = qv[0] / norm;
    out->quaternion.y = qv[1] / norm;
    out->quaternion.z = qv[2] / norm;
    out->quaternion.w = qv[3] / norm;
    out->lambda_max    = lam;
    out->loss           = lambda0 - lam;
    out->n_iterations    = iter;

    return QUEST_OK;
}

/* ------------------------------------------------------------------ */
/* Self-test (build with -DQUEST_TEST_MAIN)                            */
/* ------------------------------------------------------------------ */
#ifdef QUEST_TEST_MAIN
#include <stdio.h>

int main(void) {
    /* 30 degree rotation about Z, sun-vector + magnetic-field-vector pair */
    double theta = 30.0 * M_PI / 180.0;
    quest_vec3_t ref[2] = {
        { {1.0f, 0.0f, 0.0f} },
        { {0.0f, 0.0f, 1.0f} },
    };
    /* body_i = A(q) * ref_i, with A(q) built from the scalar-last quaternion
     * convention used throughout this codebase (see quat_to_dcm in quest.py) */
    quest_vec3_t body[2] = {
        { {(QUEST_REAL)cos(theta), (QUEST_REAL)-sin(theta), 0.0f} },
        { {0.0f, 0.0f, 1.0f} },
    };
    QUEST_REAL weights[2] = {0.7f, 0.3f};

    quest_result_t result;
    quest_status_t status = quest_solve(body, ref, weights, 2, &result);

    if (status != QUEST_OK) {
        printf("QUEST failed with status %d\n", status);
        return 1;
    }

    printf("Estimated quaternion: [%.6f, %.6f, %.6f, %.6f]\n",
           result.quaternion.x, result.quaternion.y,
           result.quaternion.z, result.quaternion.w);
    printf("Expected (approx)   : [0.000000, 0.000000, 0.258819, 0.965926]\n");
    printf("lambda_max = %.9f, loss = %.3e, iterations = %d\n",
           result.lambda_max, result.loss, result.n_iterations);

    return 0;
}
#endif /* QUEST_TEST_MAIN */
