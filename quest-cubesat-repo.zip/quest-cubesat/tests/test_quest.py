"""
test_quest.py
=============
Unit tests for the QUEST reference implementation (src/quest.py).

Run with:
    pytest tests/test_quest.py -v
"""

import sys
import os
import numpy as np
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from quest import quest, quest_sequential, quat_to_dcm, QuestError  # noqa: E402


def random_unit_vectors(n, seed=0):
    rng = np.random.default_rng(seed)
    v = rng.normal(size=(n, 3))
    return v / np.linalg.norm(v, axis=1, keepdims=True)


def quat_angle_error_deg(q1, q2):
    """Smallest rotation angle (deg) between two unit quaternions,
    accounting for the q / -q double cover of SO(3)."""
    dot = np.clip(abs(np.dot(q1, q2)), -1.0, 1.0)
    return np.degrees(2 * np.arccos(dot))


class TestQuestNoiseFree:
    def test_two_vectors_exact_recovery(self):
        theta = np.radians(42.3)
        true_q = np.array([0, 0, np.sin(theta / 2), np.cos(theta / 2)])
        A = quat_to_dcm(true_q)
        r = np.array([[1.0, 0, 0], [0, 1.0, 0]])
        b = (A @ r.T).T

        result = quest(b, r)
        assert quat_angle_error_deg(result.quaternion, true_q) < 1e-6
        assert result.loss < 1e-10
        assert result.n_iterations <= 5

    def test_random_rotation_multi_vector(self):
        rng = np.random.default_rng(42)
        axis = rng.normal(size=3)
        axis /= np.linalg.norm(axis)
        angle = rng.uniform(0.1, 3.0)  # radians, avoid the 180-deg singularity
        half = angle / 2
        true_q = np.array([*(axis * np.sin(half)), np.cos(half)])
        A = quat_to_dcm(true_q)

        r = random_unit_vectors(5, seed=1)
        b = (A @ r.T).T
        weights = rng.uniform(0.5, 1.5, size=5)

        result = quest(b, r, weights)
        assert quat_angle_error_deg(result.quaternion, true_q) < 1e-5

    def test_quaternion_is_unit_norm(self):
        r = random_unit_vectors(4, seed=2)
        b = random_unit_vectors(4, seed=3)  # arbitrary, doesn't need to be consistent
        result = quest(b, r)
        assert abs(np.linalg.norm(result.quaternion) - 1.0) < 1e-10


class TestQuestNoisy:
    @pytest.mark.parametrize("noise_std_deg", [0.1, 0.5, 2.0])
    def test_accuracy_degrades_gracefully_with_noise(self, noise_std_deg):
        rng = np.random.default_rng(7)
        theta = np.radians(55.0)
        true_q = np.array([0, 0, np.sin(theta / 2), np.cos(theta / 2)])
        A = quat_to_dcm(true_q)

        r = random_unit_vectors(6, seed=8)
        b_clean = (A @ r.T).T

        # Add small-angle random perturbations to each body vector.
        noise_rad = np.radians(noise_std_deg)
        b_noisy = b_clean + rng.normal(scale=noise_rad, size=b_clean.shape)
        b_noisy /= np.linalg.norm(b_noisy, axis=1, keepdims=True)

        result = quest(b_noisy, r)
        err = quat_angle_error_deg(result.quaternion, true_q)
        # Error should stay within a reasonable multiple of the injected noise.
        assert err < max(5.0, 10 * noise_std_deg)

    def test_monte_carlo_unbiased(self):
        """Average estimation error over many noisy trials should be small
        (QUEST is a consistent maximum-likelihood-like estimator under
        isotropic Gaussian vector noise)."""
        rng = np.random.default_rng(123)
        theta = np.radians(20.0)
        true_q = np.array([0, 0, np.sin(theta / 2), np.cos(theta / 2)])
        A = quat_to_dcm(true_q)
        r = random_unit_vectors(4, seed=99)
        b_clean = (A @ r.T).T

        errors = []
        for trial in range(200):
            noise = rng.normal(scale=np.radians(0.3), size=b_clean.shape)
            b_noisy = b_clean + noise
            b_noisy /= np.linalg.norm(b_noisy, axis=1, keepdims=True)
            result = quest(b_noisy, r)
            errors.append(quat_angle_error_deg(result.quaternion, true_q))

        assert np.mean(errors) < 1.0  # degrees


class TestQuestEdgeCases:
    def test_raises_on_single_vector(self):
        with pytest.raises(QuestError):
            quest([[1, 0, 0]], [[1, 0, 0]])

    def test_raises_on_parallel_reference_vectors(self):
        r = np.array([[1.0, 0, 0], [1.0, 0, 0]])
        b = np.array([[1.0, 0, 0], [1.0, 0, 0]])
        with pytest.raises(QuestError):
            quest(b, r)

    def test_raises_on_antiparallel_reference_vectors(self):
        r = np.array([[1.0, 0, 0], [-1.0, 0, 0]])
        b = np.array([[1.0, 0, 0], [-1.0, 0, 0]])
        with pytest.raises(QuestError):
            quest(b, r)

    def test_mismatched_shapes_raise(self):
        with pytest.raises(QuestError):
            quest([[1, 0, 0], [0, 1, 0]], [[1, 0, 0]])

    def test_near_180_degree_rotation_handled_by_sequential(self):
        theta = np.radians(179.5)
        true_q = np.array([0, 0, np.sin(theta / 2), np.cos(theta / 2)])
        A = quat_to_dcm(true_q)
        r = random_unit_vectors(4, seed=55)
        b = (A @ r.T).T

        # The direct method may be poorly conditioned here; the sequential
        # wrapper must still return a valid, accurate solution.
        result = quest_sequential(b, r)
        assert quat_angle_error_deg(result.quaternion, true_q) < 0.5


class TestConsistencyWithTriad:
    def test_two_vector_case_matches_simple_geometric_solution(self):
        """For an exact 2-vector, noise-free case, QUEST's result must be a
        genuine rotation that maps r_i back onto b_i (sanity/consistency
        check independent of the algorithm's internals)."""
        theta = np.radians(63.0)
        true_q = np.array([0.3, 0.1, np.sin(theta / 2) * 0.9, np.cos(theta / 2)])
        true_q /= np.linalg.norm(true_q)
        A = quat_to_dcm(true_q)
        r = np.array([[1.0, 0, 0], [0, 0, 1.0]])
        b = (A @ r.T).T

        result = quest(b, r)
        A_est = quat_to_dcm(result.quaternion)
        for i in range(2):
            recovered_b = A_est @ r[i]
            assert np.linalg.norm(recovered_b - b[i]) < 1e-8


if __name__ == "__main__":
    sys.exit(pytest.main([__file__, "-v"]))
